'use strict';

import SvbElement from './components/SvbElement';
import BaseInput from './components/inputs/BaseInput';

class SvbComponent {
    constructor () {
        return '';
    }

    static customComponent (tag, descriptor, id) {
        const component = SvbElement.create(tag, null, 'svbCustom__component');

        component.addAttributes({ 'view-id': id, descriptor });
        component.setContent = (content) => {
            if (content) {
                component.innerHTML = '';

                if (content instanceof HTMLElement) {
                    component.appendChild(content);
                } else {
                    component.innerHTML = content;
                }
            }
        };

        return component;
    }

    static baseInput () {
        return new BaseInput();
    }
}

export default SvbComponent;
