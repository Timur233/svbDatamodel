import SvbElement from '../SvbElement';

class BaseInput extends SvbElement {
    constructor (viewSetting, classList, inputTag = 'input') {
        super();

        if (viewSetting?.md?.type === 'virtual') {
            viewSetting.md.type = 'text';
            viewSetting.vset.readOnly = true;
        }

        this.state = {
            type:      viewSetting?.md?.type || null,
            inputType: viewSetting?.vset?.inputType || null,
            inputTag,
            controlls: [],

            value:          viewSetting?.vset?.defaultvalue || null,
            represent:      viewSetting?.vset?.defaultvalue || null,
            additionalInfo: {},

            settings: {
                hidden:    viewSetting?.vset?.hidden || false,
                password:  viewSetting?.vset?.inputType === 'password',
                clearable: viewSetting?.vset?.clearable || false,
                readOnly:  viewSetting?.vset?.readOnly || false,
                editOnly:  viewSetting?.vset?.editOnly || false,
                order:     viewSetting?.vset?.order || null,
                itarable:  viewSetting?.vset?.itarable || false,
                length:    viewSetting?.vset?.maxSymbols || null,
                precision: viewSetting?.vset?.precision || 2
            },

            style: {
                height:      viewSetting?.vset?.inputHeight || null,
                classList:   classList || '',
                noStyle:     viewSetting?.vset?.noStyle || false,
                textAlign:   viewSetting?.vset?.textAlign || 'left',
                placeholder: viewSetting?.vset?.placeholder || null
            }
        };

        this.baseInit(viewSetting);
        this.render();

        return this.component;
    }

    baseInit (viewSetting) {
        this.component = SvbElement.create('div', null, `svbInput ${this.state.style.classList}`);
        this.represent = SvbElement.create('span', null, 'svbInput__represent');
        this.input = SvbElement.create(this.state.inputTag, null, null);
        this.controll = SvbElement.create('div', null, 'svbInput__controll');
        this.fragment = null;

        if (this.state.style.noStyle === true) this.component.classList.add('svbInput--nostyle');

        if (this.state.settings.clearable) {
            this.addControllBtn('<i class="fa-solid fa-xmark"></i>', '', () => {
                this.clearValue();

                this.eventChange();
            });
        }

        this.eventInput = () => {};
        this.eventChange = () => {};
        this.eventShowModal = () => {};
        this.eventSet = () => {};
        this.eventClick = () => {};
        this.eventBlur = () => {};
        this.eventSelectDropdown = () => {};
        this.eventEndEdit = () => {};
        this.formatter = v => v;

        this.component.utilityObject = this;

        this.component.getInputValue = BaseInput.getInputValue;
        this.component.setValue = BaseInput.setValue;
        this.component.disable = this.disable.bind(this);

        this.component.dataset.isIterable = this.state.settings.itarable;

        this.renderWrapper();
        this.defaultEvents();
    }

    defaultEvents () {
        this.event('click', this.represent, () => {
            this.representClickMethod();
        });

        this.event('keydown', this.input, (event) => {
            if (this.state.settings.itarable && event.keyCode === 13) {
                event.preventDefault();

                if (event.ctrlKey || event.metaKey) this.input.value += '\n';

                if (event.shiftKey) {
                    this.bypassFields(-1);

                    return;
                }

                this.bypassFields(1);
            }

            if (this.state.settings.itarable && event.keyCode === 9) {
                event.preventDefault();

                if (event.shiftKey) {
                    BaseInput.deactivateAll(this.component);
                    this.eventEndEdit(-1);

                    return;
                }

                BaseInput.deactivateAll(this.component);
                this.eventEndEdit(1);
            }
        });

        this.event('click', this.controll, (event) => {
            const path = event.path || (event.composedPath && event.composedPath());

            if (!path) throw new Error('Tbody, Event click: browser is not supported');

            path.forEach((item) => {
                if (item !== window &&
                        item !== document &&
                        item.classList.contains('svbInput__btn')) {
                    item.callback();
                }
            });
        });

        this.event('input', this.input, (event) => {
            this.inputMethod(event);
        });

        this.event('change', this.input, (event) => {
            this.changeMethod(event);
        });

        this.input.addEventListener('blur', (event) => {
            this.eventBlur(event);
        });

        // this.event('blur', this.input, (event) => {
        //     this.eventBlur(event);
        // });

        this.event('dragstart', this.input, (event) => {
            event.preventDefault();
            event.stopPropagation();

            return false;
        });
    }

    representClickMethod () {
        this.eventClick();

        if (this.attributeRow) {
            BaseInput.deactivateAll(this.component);
            this.activateMulti(this.attributeRow.attributeList);
        } else {
            if (this.state.settings.readOnly) return;

            BaseInput.deactivateAll(this.component);
            this.activate();
        }
    }

    changeMethod (event) {
        event.stopPropagation();
        event.preventDefault();

        this.eventChange(event, this.component);
    }

    inputMethod (event) {
        event.stopPropagation();
        event.preventDefault();

        this.setValue(this.formatter(event.target.value));
        this.eventInput(event, this.component);
    }

    disable (isDisable = false) {
        this.state.settings.readOnly = isDisable;
        this.state.settings.editOnly = false;

        this.renderWrapper();
        this.renderRepresent();
        this.render();
    }

    setValue (value) {
        this.state.value = String(value || '');
        this.state.represent = this.state.value.split('\n').join('<br>');

        this.input.value = this.state.value;

        this.eventSet();
        this.renderRepresent();
    }

    clearValue (isPublic = true) {
        this.state.represent = null;
        this.state.value = null;
        this.state.date = null;

        this.input.value = '';

        if (isPublic) this.eventSet();

        this.renderInput();
        this.renderRepresent();
        this.input.focus();
    }

    clear () {
        while (this.component.firstChild) {
            this.component.removeChild(this.component.firstChild);
        }

        if (this.fragment) this.fragment = null;
    }

    showRepresent () {
        this.renderRepresent();
        this.component.appendChild(this.represent);
        this.component.classList.add('svbInput--represent');
    }

    addControllBtn (content = '', className = '', callback = null, id = null) {
        const buttonId = id || Math.floor(Math.random() * 100000000);
        const buttomObject = {
            id:      buttonId,
            className,
            content,
            callback,
            order:   this.state.controlls.length,
            element: null
        };

        this.state.controlls.push(buttomObject);
        this.renderControllBtn(buttonId);
        this.controll.appendChild(buttomObject.element);

        return buttomObject;
    }

    activate (isFocus = true) {
        if (this.state.settings.readOnly === true) return;

        if (!this.component.classList.toggle('svbInput--represent')) {
            this.clear();

            this.component.appendChild(this.input);

            if (isFocus) this.input.focus();

            this.renderInput();
            this.renderControll();
        }
    }

    activateMulti (inputs = []) {
        inputs.forEach((item) => {
            item.utilityObject.activate(false);
        });

        this.input.focus();
    }

    deactivate () {
        if (this.state.settings.editOnly === true) return;

        this.input.dispatchEvent(new Event('blur'));

        this.clear();
        this.showRepresent();
    }

    bypassFields (direction = 1) {
        const parent = BaseInput.deactivateAll(this.component);
        const findField = (arrow, component) => {
            const fields = Array.from(parent.querySelectorAll('.svbInput[data-bypassindex]'))
                .sort((a, b) => a?.dataset?.bypassindex - b?.dataset?.bypassindex);
            const filteredFields = fields.filter(i => !(i === undefined ||
                i.utilityObject.state.settings.readOnly ||
                i.utilityObject.state.settings.hidden ||
                i.utilityObject.state.type === 'boolean'));
            const firstIndex = 0;
            const lastIndex = filteredFields.length - 1;
            const filedIndex = filteredFields.findIndex(i => i === component);
            const field = filteredFields[filedIndex + arrow];

            if ((arrow === 1 && filedIndex >= lastIndex) ||
                (arrow === -1 && filedIndex <= firstIndex)) return null;

            return field;
        };

        const followField = findField(direction, this.component);

        if (!followField) {
            this.activate(true);
            this.eventEndEdit(direction);

            return false;
        }

        if (parent.classList.contains('svbTable__row') ||
            parent.classList.contains('svbTree-item')) {
            this.activateMulti(this.attributeRow.attributeList);
            followField.utilityObject.input.focus();

            return false;
        }

        followField.utilityObject.activate(true);
        followField.scrollIntoView();

        return false;
    }

    renderWrapper () {
        if (this.state.settings.readOnly === true) {
            this.component.classList.add('svbInput--readonly');
        } else {
            this.component.classList.remove('svbInput--readonly');
        }

        if (this.state.inputTag === 'input') {
            this.component.addStyles({
                height: this.state.style.height ? `${this.state.style.height}px` : 'auto'
            });
        }
    }

    renderRepresent () {
        const represent = this.state.settings.password
            ? '•'.repeat(this.state.represent?.length || 0)
            : this.state.represent;

        this.represent.innerHTML = represent || '';
        this.component.setAttribute('title', represent);

        this.represent.addStyles({
            textAlign: this.state.style.textAlign
        });
    }

    renderInput () {
        this.input.type = this.state.settings.password ? 'password' : 'text';
        this.input.value = this.state.value;
        this.input.classList.add('svbInput__text');
        this.input.placeholder = this.state.style.placeholder || 'Введите текст';
        // this.input.setAttribute('draggable', true);

        this.component.setAttribute('title', this.state.represent);

        this.input.addStyles({
            textAlign: this.state.style.textAlign,
            height:    this.state.style.height ? `${this.state.style.height}px` : 'auto'
        });

        // console.log('baseInput', this.state.style);

        if (this.state.settings.length) {
            this.input.setAttribute('maxlength', this.state.settings.length);
        }
    }

    renderControllBtn (buttonId) {
        const buttonObject = this.state.controlls.find(item => item.id === buttonId);
        const { className, content, callback } = buttonObject;
        const button = SvbElement.create('button', null, `svbInput__btn ${className}`);

        button.innerHTML = content;
        button.callback = (event) => {
            if (callback) callback(event, this.component);
        };

        buttonObject.element = button;

        return button;
    }

    renderControll () {
        this.clearComponent(this.controll);

        this.state.controlls.forEach((button) => {
            this.controll.appendChild(button.element);
        });

        this.component.appendChild(this.controll);
    }

    render () {
        this.clear();

        if (this.state.settings.editOnly === true) {
            this.renderInput();
            this.component.appendChild(this.input);

            this.renderControll();
        } else {
            this.showRepresent();
        }

        return this.component;
    }

    static deactivateAll (element) {
        let parent = document.body;
        let moreInputs = null;

        while (element.parentNode !== document.body) {
            if (element.parentNode.classList.contains('svbPanel') ||
                element.parentNode.classList.contains('svbModal') ||
                element.parentNode.classList.contains('svbWindow') ||
                element.parentNode.classList.contains('svbTable__row') ||
                element.parentNode.classList.contains('svbTree-item') ||
                element.parentNode.classList.contains('svbTable') ||
                element.parentNode.classList.contains('svbTree')
            ) {
                parent = element.parentNode;
                break;
            }

            element = element.parentNode;
        }

        moreInputs = parent.querySelectorAll('.svbInput:not(.svbInput--represent)');

        Array.from(moreInputs).forEach((input) => {
            if (input) input?.utilityObject?.deactivate();
        });

        return parent;
    }

    static getInputValue () {
        let response;

        if (this.utilityObject.state.settings.readOnly === true) {
            switch (this.state.type) {
                case 'date':
                case 'timestamp':
                    response = this.utilityObject.state.value;
                    break;
                default:
                    response = this.utilityObject.state.value;
                    break;
            }

            return response;
        }

        switch (this.utilityObject.state.type) {
            case 'text':
                response = this.utilityObject.state.value;

                break;
            case 'timestamp':
            case 'date':
                response = new Date(this.utilityObject.state.date);

                break;
            case 'numeric':
                response = this.utilityObject.state.value;

                break;
            case 'boolean':
                response = this.utilityObject.state.value;
                break;
            case 'catalog':
            case 'document':
            case 'system':
                response = {
                    r: this.utilityObject.state.represent,
                    v: this.utilityObject.state.value
                };
                break;
            default:
                response = this.utilityObject.state.value;
                break;
        }

        return response;
    }

    static setValue (value) {
        this.utilityObject.setValue(value);
    }
}

export default BaseInput;
